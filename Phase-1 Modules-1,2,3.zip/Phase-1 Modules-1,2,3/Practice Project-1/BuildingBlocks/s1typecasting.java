package BuildingBlocks;

public class s1typecasting {
	public static void main(String[] args) {
	
		
		
String input = "12";
	
		
	byte mybyte = Byte.parseByte(input);
	System.out.println("Byte val =" + mybyte);
		
		int myint = Integer.parseInt(input);
		System.out.println("Integer val = " + myint);

		double d = Double.parseDouble(input);
		System.out.println(d);
		
		int i  = Integer.valueOf(input);
		System.out.println(i);
				
		double x=3.14;
		int y=(int)x;
		System.out.println("Value of x: "+x);
		System.out.println("Value of y: "+y);

	}
}
