package pack2;
import pack1.*;
public class protectedAccessSpecifiers extends proaccessspecifiers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		protectedAccessSpecifiers obj = new protectedAccessSpecifiers ();   
	       obj.display();  
	}

}
