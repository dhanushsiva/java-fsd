package threadcreation;

public class Thread {
	public Thread(MyRunnableThread mrt) {
		// TODO Auto-generated constructor stub
	}

	public static void main( String args[] )
 	{
  		
 	}

	public static void sleep(int i) {
		// TODO Auto-generated method stub
		
	}

	public void start() {
		// TODO Auto-generated method stub
		
	}
	
}
