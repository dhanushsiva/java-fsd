package PillarsofOOPs;
//for shape
public class Test  
{ 
    public static void main(String[] args) 
    { 
        Shape s1 = new Circle("Red", 2.2); 
        Shape s2 = new Rectangle("Yellow", 2, 4);
        System.out.println(s1.toString()); 
        System.out.println(s2.toString()); 
    } 
}

//for bicycle
public class Test  
{ 
    public static void main(String args[])  
    { 
        MountainBike mb = new MountainBike(3, 100, 25); 
        System.out.println(mb.toString());
    } 
}