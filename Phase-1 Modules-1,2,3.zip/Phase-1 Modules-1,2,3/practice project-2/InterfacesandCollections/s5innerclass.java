package InterfacesandCollections;

public class s5innerclass {

	 private String str="hello"; 
	 
	 class Inner
	 {  
	  void hello()
	  {
		  System.out.println(str +", its nice to meet you.");}  
	  }  


	public static void main(String[] args) {

		s5innerclass s=new s5innerclass();
		s5innerclass.Inner in=s.new Inner();  
		in.hello();  
	}
}










