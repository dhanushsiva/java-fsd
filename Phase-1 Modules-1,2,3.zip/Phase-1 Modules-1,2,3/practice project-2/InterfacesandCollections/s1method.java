package InterfacesandCollections;

public class s1method {

	static void myMethod() 
	{
		    System.out.println("welcome aboard strangers");
    }
	static void myMethod2() 
	{
		    System.out.println("fell free to talk");
    }

		  public static void main(String[] args) {
		    myMethod();
		    myMethod2();
		  }
		}