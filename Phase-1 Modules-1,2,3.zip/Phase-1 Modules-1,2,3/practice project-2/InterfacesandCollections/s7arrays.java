package InterfacesandCollections;

public class s7arrays {

public static void main(String[] args) {


int arr[]= {1,3,7,9,11};
for(int i=0;i<=5;i++) 
{
System.out.println(arr[i]);
}

}}



