package InterfacesandCollections;

public class s2constructors {

	  
	    int id;  
	    String name;  
	    // constructor  
	    s2constructors(int i,String n)
	    {  
	      id = i;  
	      name = n;  
	    }  
	      
	    void display()
	        {
	    	    System.out.println(id+" "+name);
	    	}  
	    
	   
	    public static void main(String args[])
	    {  
	    
	    	s2constructors s1 = new s2constructors(21,"roland");  
	    	s2constructors s2 = new s2constructors(22,"jackson");  
	    
	      s1.display();  
	      s2.display();  
	   }  
	}  
