package com.download.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZuulExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZuulExampleApplication.class, args);
	}

}
