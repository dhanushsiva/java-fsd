package com.download.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuulExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
