package loanapplications;

import org.testng.annotations.Test;

public class HomeLoanApplicationTests {

//	@Test
//	public void HomeLoanLoginWeb() {
//		System.out.println("Home loan application - web login test");
//	}
//	
//	@Test
//	public void HomeLoanLoginMobile() {
//		System.out.println("Home loan application - mobile login test");
//	}
//	
//	@Test
//	public void HomeLoanLoginAPI() {
//		System.out.println("Home loan application - API login test");
//	}
	
	@Test
	public void WebHomeLoan() {
		System.out.println("Home loan application - web login test");
	}
	
	@Test
	public void MobileHomeLoan() {
		System.out.println("Home loan application - mobile login test");
	}
	
	@Test
	public void APIHomeLoan() {
		System.out.println("Home loan application - API login test");
	}
}