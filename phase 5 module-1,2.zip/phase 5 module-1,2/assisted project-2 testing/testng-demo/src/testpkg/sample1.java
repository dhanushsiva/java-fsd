package testpkg;

import org.testng.annotations.Test;

public class sample1 {

	@Test
	public void demo() {
		System.out.println("hello");
	}
	
}