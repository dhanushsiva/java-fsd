function storeData() {
    // get emailid and password using id attribute 
    // store both information in localStorage or sessionStorage 
    
}