package automateecommerceflipkart;

public class edgeautotestflipkart {

}
